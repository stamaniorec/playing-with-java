import java.util.Arrays;

public class ProblemThirteen {

	// binary search
	public static void main(String[] args) {
		
		int[] array = { 1, 5, 3, 0, 123 };
		Arrays.sort(array);
		int searchValue = -5;
		int low = 0;
		int high = array.length;
		int mid = -1000;
		boolean found = false;
		while (low <= high) {
			mid = (low + high) / 2;
			if (array[mid] == searchValue) {
				found = true;
				break;
			} else if (array[mid] < searchValue) {
				low = mid + 1;
			} else { 
				high = mid - 1;
			}
		}
		if (found) {
			System.out.println("Element found at " + mid + "th position");
		} else { 
			System.out.println("Element not found.");
		}
	}
	
}
