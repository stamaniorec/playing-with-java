import java.util.Scanner;
import java.util.Arrays;

public class ProblemSix {

	// read N and K 
	// create array of N elements
	// find K numbers with greatest sum
	public static void main(String[] args) {
	
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int K = input.nextInt();
		
		int[] array = new int[N];
		for(int k = 0; k < N; k++) {
			array[k] = input.nextInt();
		}
		
		Arrays.sort(array);
		int counter = 0;
		
		// I could use a stack or something to print the numbers in correct order
		// but whatever
		for(int i = array.length - 1; i >= 0; i--) {
			System.out.print(array[i] + " ");
			
			if(++counter >= K) {
				break;
			}
		}
		
		input.close();
	}
	
}
