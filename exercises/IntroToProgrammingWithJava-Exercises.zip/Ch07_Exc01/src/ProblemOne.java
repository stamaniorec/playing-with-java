
public class ProblemOne {

	// array with 20 elements
	// init every element to value of index * 5
	
	public static void main(String[] args) {
		
		int[] array = new int[20];
		for (int i = 0; i < array.length; i++) {
			array[i] = i * 5;
		}
		
		for(int j = 0; j < array.length; j++) { 
			System.out.print(array[j] + " ");
		}
		
	}
	
}
