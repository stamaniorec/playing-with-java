import java.util.Scanner;

public class BinaryToHexadecimal {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		String userInput = input.nextLine();
		
		int counter = 0;
		String result = "";
		
		String substring = "";
		if (userInput.length() % 4 != 0) {
			for (int k = 0; k < userInput.length() % 4; k++) {
				userInput = "0" + userInput;
			}
			// userInput.length() % 4 is the number of 0s I need to
			// prepend on the string
		}
		
		for (int i = userInput.length() - 1; i >= 0; i--) {
			if (counter++ >= 3) {
				substring = userInput.substring(i, i+4);
				counter = 0;
				//System.out.println(substring);
				switch(substring) {
				case "0000":
					result += "0";
					break;
				case "0001":
					result += "1";
					break;
				case "0010":
					result += "2";
					break;
				case "0011":
					result += "3";
					break;
				case "0100":
					result += "4";
					break;
				case "0101":
					result += "5";
					break;
				case "0110":
					result += "6"; 
					break;
				case "0111":
					result += "7";
					break;
				case "1000":
					result += "8";
					break;
				case "1001":
					result += "9";
					break;
				case "1010":
					result += "A";
					break;
				case "1011":
					result += "B";
					break;
				case "1100":
					result += "C";
					break;
				case "1101":
					result += "D";
					break;
				case "1110":
					result += "E";
					break;
				case "1111":
					result += "F";
					break;
				}
			}
		}
		
		for (int z = result.length() - 1; z >= 0; z--) {
			System.out.print(result.charAt(z));
		}
		
		input.close();
	
	}
	
}

