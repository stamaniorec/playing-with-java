import java.util.Scanner;

public class ProblemSeven {

	public static void main(String[] args) { 
		Scanner input = new Scanner(System.in);
		int number = input.nextInt();
		//int number = 123;
		
		System.out.println(reverse(number));
		
		input.close();
	}
	
	// 123
	public static int reverse(int a) {
		int result = 0;
		while(a != 0) {
			result = result*10 + a % 10;
			a /= 10;
		}
		return result;
	}
	
}
