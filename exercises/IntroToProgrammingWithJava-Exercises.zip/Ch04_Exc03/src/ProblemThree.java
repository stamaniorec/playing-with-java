import java.util.Scanner;

public class ProblemThree {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter firm name: ");
		String firmName = input.nextLine();
		
		System.out.println("Enter address: ");
		String address = input.nextLine();
		
		System.out.println("Enter website: ");
		String website = input.nextLine();
		
		// Was way too lazy to do the other ones
		
		System.out.println("Name: " + firmName + "\nAddress: " + 
			address + "\nWebsite: " + website);
		
		input.close();
	}
	
}
