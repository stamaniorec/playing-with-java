import java.util.Scanner;

public class DecimalToHexadecimal {

	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		int userNumber = input.nextInt();
		String result = "";
		
		while (userNumber != 0) {
			int remainder = userNumber % 16;
			if (remainder >= 0 && remainder < 10) {
				result += remainder;
			} else { 
				switch(remainder) {
				case 10:
					result += "A";
					break;
				case 11: 
					result += "B";
					break;
				case 12: 
					result += "C";
					break;
				case 13: 
					result += "D";
					break;
				case 14: 
					result += "E";
					break;
				case 15: 
					result += "F";
					break;
				}
			}
			
			userNumber /= 16;
		}
		
		for (int i = result.length() - 1; i >= 0; i--) {
			System.out.print(result.toCharArray()[i]);
		}
		
		input.close();
	}
	
}
