import java.util.Scanner;

public class ProblemFour {

	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter two numbers: ");
		int a = input.nextInt();
		int b = input.nextInt();
		
		int counter = 0;
		
		for (int i = a + 1; i < b; i++) {
			if (i % 5 == 0) {
				counter++;
			}
		}
		
		System.out.println(counter);
		
		input.close();
		
		// Problem 5 requires some fancy altho simple math
		// the other ones are simple loops
	}
	
}
