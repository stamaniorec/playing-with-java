import java.util.Scanner;

public class DecimalToBinary {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		int number = input.nextInt();
		
		int[] array = new int[100];
		int i = 0;
		while (number != 0) {
			array[i++] = number % 2;
			//System.out.print(array[i] + " ");
			number /= 2;
		}
		
		//System.out.println(i);
		for (int j = i - 1; j >= 0; j--) {
			System.out.print(array[j]);
		}
		
		input.close();
	}
	
}
