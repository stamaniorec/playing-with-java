
public class ProblemSix {

	public static void main(String[] args) {
		int[] array = { 1, 3, 2 };
		
		System.out.println(firstElementGreaterThanBothNeighbors(array));
	}
	
	public static int firstElementGreaterThanBothNeighbors(int[] array) {
		for (int i = 1; i < array.length - 1; i++) {
			if (array[i] > array[i-1] && array[i] > array[i+1]) {
				return i;
			}
		}
		return -1;
	}
	
}
