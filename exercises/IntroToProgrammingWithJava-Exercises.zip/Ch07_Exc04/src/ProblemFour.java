
public class ProblemFour {

	// greatest number of numbers in row
	// {2, 1, 1, 2, 3, 3, 2, 2, 2, 1}   ---> 2 2 2
	public static void main(String[] args) { 
		
		int[] array = { 2, 1, 1, 2, 3, 3, 2, 2, 2, 1 };
		
		int number = -1, best_number = -1;
		int encounters = 1;
		int best_encounters = 1;
		for(int i = 0; i < array.length - 1; i++) {
			if(array[i] == array[i+1]) {
				number = array[i];
				encounters++;
			} else { 
				encounters = 1;
			}
			if(encounters > best_encounters) {
				best_number = number;
				best_encounters = encounters;
				encounters = 1;
			}
		}
		
		for(int j = 0; j < best_encounters; j++) {
			System.out.print(best_number + " ");
		}
		
	}
	
}
