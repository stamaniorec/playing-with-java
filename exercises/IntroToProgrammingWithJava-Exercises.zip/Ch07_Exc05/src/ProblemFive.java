
public class ProblemFive {

	// {3, 2, 3, 4, 2, 2, 3, 4} ---> {2, 3, 4}
	public static void main(String[] args) { 
		
		int[] array = { 3, 2, 3, 4, 5, 2, 5, 6, 7, 8, 9 };
		
		// not sure if it should be just ascending numbers 
		// or numbers like a, a+1, a+2, a+3...
		
		int counter = 0;
		boolean flag = false;
		int firstNumber = -1000;
		int best_counter = -1;
		int bestFirstNumber = 0;
		
		for(int i = 0; i < array.length - 1; i++) {
			if(array[i] + 1 == array[i+1]) {
				counter++;
				if(!flag) {
					firstNumber = array[i];
					flag = true;
				}
			} else {
				if(flag) {
					flag = false;
				}
				if(counter > best_counter) {
					best_counter = counter;
					bestFirstNumber = firstNumber;
				}
				counter = 0;
				
			}
		}
		if(counter > best_counter) {
			bestFirstNumber = firstNumber;
			best_counter = counter;
		}
		
		for(int j = 0; j <= best_counter; j++) {
			System.out.println((bestFirstNumber + j));
		}
		
	}
	
}
