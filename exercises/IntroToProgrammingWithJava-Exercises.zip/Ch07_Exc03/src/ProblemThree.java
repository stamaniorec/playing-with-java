
public class ProblemThree {

	public static void main(String[] args) {
		
		String str1 = "hell";
		String str2 = "hello";
		
		char[] str11 = str1.toCharArray(); // apparently I can't compare 
		char[] str22 = str2.toCharArray(); // individual string elements
		
		boolean which = true; // false for first, true for second
		
		if(str1.length() != str2.length()) {
			which = (str1.length() > str2.length()) ? true : false;
		} else { 
			for (int i = 0; i < str1.length(); i++) {
				if (str11[i] < str22[i]) { 
					which = false;
					break;
				}
 			}
		}
		
		System.out.printf("%b \n", which);
		
	}
	
}
