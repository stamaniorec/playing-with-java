import java.util.Scanner;

public class ProblemEleven {

	// 3x3 platform with greatest sum
	public static void main(String[] args) { 
		Scanner input = new Scanner(System.in);
		
		System.out.print("Please enter matrix size: ");
		int m = input.nextInt();
		int n = input.nextInt();
		
		int[][] matrix = new int[m][n];
		
		System.out.println("Please enter matrix values: ");
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++ ) { 
				matrix[i][j] = input.nextInt();
			}
		}
		
		int bestSum = 0, bestStartX = 0, bestStartY = 0;
		for (int a = 0; a < m - 2; a++) {
			for (int b = 0; b < n - 2; b++) {
				int currentSum = matrix[a][b] + matrix[a][b+1] + 
					matrix[a][b+2] + matrix[a+1][b] + matrix[a+1][b+1] +
					matrix[a+1][b+2] + matrix[a+2][b] + matrix[a+2][b+1] +
					matrix[a+2][b+2];
				if (currentSum > bestSum) {
					bestSum = currentSum;
					bestStartX = a;
					bestStartY = b;
				}
			}
		}
		
		System.out.println("The 3x3 with the greatest sum starts from position ");
		System.out.println(bestStartX + "," + bestStartY);
		
		input.close();
		
	}
	
}
