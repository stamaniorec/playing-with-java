
public class ProblemTwo {

	// we read two arrays 
	// are they identical?
	
	public static void main(String[] args) { 
		
		// ah, apparently I need an ArrayList or something 
		// to create an array without knowing its size beforehand
		// yeah, this program is kinda dumb the way it is now
		
		int[] arr1 = { 1, 2, 5 };
		int[] arr2 = { 1, 2, 6 };
		
		boolean are_identical = true;
		
		if(arr1.length != arr2.length) {
			are_identical = false;
		} else { 
			for (int i = 0; i < arr1.length; i++) {
				if (arr1[i] != arr2[i]) {
					are_identical = false;
				}
			}	
		}
		
		System.out.println("Are identical? " + are_identical);
		
	}
	
}
