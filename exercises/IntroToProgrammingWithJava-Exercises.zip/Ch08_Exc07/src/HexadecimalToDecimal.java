import java.util.Scanner;

public class HexadecimalToDecimal {

	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		String userInput = input.nextLine();
		char[] hex = userInput.toCharArray();
		
		int result = 0;
		int cur = 0;
		int curPower = 0;
		for (int i = userInput.length() - 1; i >= 0; i--) {
			if (hex[i] >= '0' && hex[i] <= '9') {
				cur = hex[i] - '0';
			} else { 
				switch(hex[i]) {
				case 'A':
					cur = 10;
					break;
				case 'B':
					cur = 11;
					break;
				case 'C': 
					cur = 12;
					break;
				case 'D': 
					cur = 13;
					break;
				case 'E': 
					cur = 14;
					break;
				case 'F':
					cur = 15;
					break;
				}
			}
			result += cur * Math.pow(16, curPower++);
		}
		
		System.out.println(result);
		
		input.close();
	}
	
}
