import java.util.Scanner;

public class ProblemOne {

	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		String name = input.next();
		
		System.out.println(greeting(name));
		
		input.close();
		
	}
	
	public static String greeting(String name) { 
		return "Hello " + name;
	}
	
}
