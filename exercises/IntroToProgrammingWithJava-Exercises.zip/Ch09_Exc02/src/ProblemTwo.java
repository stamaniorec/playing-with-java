import java.util.Scanner;

public class ProblemTwo {

	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		
		System.out.println(greater(greater(a, b), c));
	
		input.close();
		
	}
	
	public static int greater(int a, int b) {
		return a > b ? a : b;
	}
	
}
