
public class ProblemEight {

	// most occurring number in array
	public static void main(String[] args) {
		
		int[] array = { 4, 1, 1, 4, 2, 3, 4, 4, 1, 2, 4, 9, 3 };
		int[] numbers = new int[10];
		
		for (int i = 0; i < array.length; i++) {
			++numbers[array[i]];
		}
		
		int max = 0;
		for (int j = 1 ; j < numbers.length; j++) {
			if (numbers[j] > numbers[max]) {
				max = j;
			}
		}
		System.out.println(max + " (" + numbers[max] + " times)");
		
	}
	
}
