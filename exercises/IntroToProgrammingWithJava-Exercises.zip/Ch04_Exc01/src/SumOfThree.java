import java.util.Scanner;

public class SumOfThree {

	public static void main(String[] args) { 
		Scanner input = new Scanner(System.in);
		
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		
		System.out.println("Sum of numbers: " + (a+b+c));
		
		input.close();
		
	}
	
}
