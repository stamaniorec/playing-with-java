
public class ProblemFour {

	public static void main(String[] args) {
		int[] array = { 1, 2, 2, 3, 3, 3, 3, 4, 4, 5, 5 };
		
		System.out.println(numberOfTimesContained(array, 5));
	}
	
	public static int numberOfTimesContained(int[] arr, int val) {
		int result = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == val) {
				result++;
			}
		}
		return result;
	}
	
}
