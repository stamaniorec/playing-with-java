
public class Matrix {
	
	public static void main(String[] args) {
		// In Spiral order
		int size = 4;
		int[][] matrix = new int[size][size];
		
		int top = 0, bottom = size - 1, left = 0, right = size - 1;
		int dir = 0;
		int number = 1;
		while (left <= right && top <= bottom) {
			if (dir == 0) { // down
				for (int i = top; i <= bottom; i++) {
					matrix[i][left] = number++;
				}
				left++;
			} else if (dir == 1) { // right
				for (int i = left; i <= right; i++) {
					matrix[bottom][i] = number++;
				}
				bottom--;
			} else if (dir == 2) { // up
				for (int i = bottom; i >= top; i--) {
					matrix[i][right] = number++;
				}
				right--;
			} else if (dir == 3) { // left 
				for (int i = right; i >= left; i--) {
					matrix[top][i] = number++;
				}
				top++;
			}
			
			if (dir == 3) {
				dir = 0;
			} else { 
				dir++;
			}
		}
		
		for (int rows = 0; rows < 4; rows++) {
			for (int columns = 0; columns < 4; columns++) {
				System.out.print(matrix[rows][columns] + " ");
			}
			System.out.println("");
		}
		
		// In diagonal strips
		int[][] m1 = new int[size][size];
		
		number = 0;
		int a = 0;
		for (int i = 0; i < size; i++) {
			a = 0;
			for (int j = 0; j <= i; j++) {
				m1[size-i-1+a][j] = ++number;
				a++;
			}
		}
		a = 1;
		for (int k = size - 1; k > 0; k--) {
			for (int i = size - k; i < size; i++) {
				m1[i-a][i] = ++number;
			}
			a++;
		}
		
		for (int rows = 0; rows < 4; rows++) {
			for (int columns = 0; columns < 4; columns++) {
				System.out.print(m1[rows][columns] + " ");
			}
			System.out.println("");
		}
		
	}
			
}
