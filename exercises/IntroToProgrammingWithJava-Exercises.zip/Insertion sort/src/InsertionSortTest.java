
public class InsertionSortTest {

	public static void main(String[] args) {
		
		InsertionSort sort = new InsertionSort();
		int[] array = new int[10];
		for(int i = 0; i < 10; i++)
		{
			array[i] = 9 - i;
		}
		sort.insertionSort(array);
		for(int j = 0; j < 10; j++) {
			System.out.print(array[j] + " ");
		}
	}
	
	
}
