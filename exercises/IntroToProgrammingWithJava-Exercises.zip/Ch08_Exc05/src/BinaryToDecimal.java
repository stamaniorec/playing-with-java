import java.util.Scanner;

public class BinaryToDecimal {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		String userInput = input.nextLine();
		char[] inBinary = userInput.toCharArray();
		
		int inDecimal = 0;
		int curPower = 0;
		for (int i = userInput.length() - 1; i >= 0; i--) {
			if (inBinary[i] == '1') {
				inDecimal += Math.pow(2, curPower);
			}
			curPower++;
		}
		
		System.out.println(inDecimal);
		
		input.close();
		
	}
	
}
