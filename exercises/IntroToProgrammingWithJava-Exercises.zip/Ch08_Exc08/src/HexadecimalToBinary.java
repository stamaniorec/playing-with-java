import java.util.Scanner;

public class HexadecimalToBinary {

	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		String userInput = input.nextLine();
		char[] hex = userInput.toCharArray();
		
		String result = "";
		String curBinary = "";
		for (int i = 0; i < userInput.length(); i++) {
			switch(hex[i]) {
			case '0': 
				curBinary = "0000";
				break;
			case '1':
				curBinary = "0001";
				break;
			case '2':
				curBinary = "0010";
				break;
			case '3':
				curBinary = "0011";
				break;
			case '4':
				curBinary = "0100";
				break;
			case '5':
				curBinary = "0101";
				break;
			case '6':
				curBinary = "0110";
				break;
			case '7':
				curBinary = "0111";
				break;
			case '8':
				curBinary = "1000";
				break;
			case '9':
				curBinary = "1001";
				break;
			case 'A':
				curBinary = "1010";
				break;
			case 'B':
				curBinary = "1011";
				break;
			case 'C':
				curBinary = "1100";
				break;
			case 'D':
				curBinary = "1101";
				break;
			case 'E':
				curBinary = "1110";
				break;
			case 'F':
				curBinary = "1111";
				break;
			}
			result += curBinary + " "; 
		}
		
		System.out.println(result);
		
		input.close();
	}
	
}
