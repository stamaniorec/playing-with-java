
public class SwitchLeastAndGreatest {

	void switchLeastAndGreatest(int[] array) {
		int least = 0;
		int greatest = 0;
		for (int i = 1; i < array.length; i++) {
			if (array[i] < array[least]) {
				least = i;
			}
			if (array[i] > array[greatest]) { 
				greatest = i;
			}
		}
		int temp = array[least];
		array[least] = array[greatest];
		array[greatest] = temp;
	}
	
}
