
public class SwitchLeastAndGreatestTest {

	public static void main(String[] args) {
		SwitchLeastAndGreatest a = new SwitchLeastAndGreatest();
		int[] array = new int[10];
		for(int i = 0; i < array.length; i++) { 
			array[i] = i;
		}
		a.switchLeastAndGreatest(array);
		for(int j = 0; j < array.length; j++) {
			System.out.print(array[j] + " ");
		}
	}
	
}
