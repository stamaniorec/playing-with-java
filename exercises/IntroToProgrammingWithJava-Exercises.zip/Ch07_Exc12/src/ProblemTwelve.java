import java.util.Scanner;

public class ProblemTwelve {

	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		
		String userWord = input.next();
		char[] word = userWord.toCharArray();
		
		for (int i = 0; i < userWord.length(); i++) {
			System.out.println(word[i] + " : " + (word[i] - 'a' + 1));
		}
		
		input.close();
		
	}
	
}
