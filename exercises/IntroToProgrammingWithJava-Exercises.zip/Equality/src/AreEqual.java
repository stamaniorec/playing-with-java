
public class AreEqual {
	
	// how do I use templates?! :P
	
	boolean areEqual(int a, int b) { 
		return a == b;
	}
	
	boolean areEqual(double a, double b) { 
		return a == b;
	}
	
	boolean areEqual(String a, String b) { 
		return a == b;
	}
	
}
