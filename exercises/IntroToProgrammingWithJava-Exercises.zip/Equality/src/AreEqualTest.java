
public class AreEqualTest {

	public static void main(String[] args) { 
		AreEqual object = new AreEqual();
		
		String a = "aaa"; // to hell with you Head First Java, this works!
		String b = "aaa"; // even tho the two variables have different addresses
		
		System.out.println(object.areEqual(5, 5));
		System.out.println(object.areEqual(5.500, 5.501));
		System.out.println(object.areEqual(a, b));
	}
	
	
}
