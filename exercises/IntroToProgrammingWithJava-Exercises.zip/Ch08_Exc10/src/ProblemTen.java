import java.util.Scanner;

public class ProblemTen {

	// Shema na Horner   Binary --> Decimal
	public static void main(String[] args) { 
		
		Scanner input = new Scanner(System.in);
		String userInput = input.next();
		
		int result = 0;
		for (int i = 0; i < userInput.length(); i++) { 
			result += userInput.charAt(i) - '0';
			if (i != userInput.length() - 1) {
				result *= 2;
			}
		}
		
		System.out.println(result);
		
		
		input.close();
		
	}
	
}
