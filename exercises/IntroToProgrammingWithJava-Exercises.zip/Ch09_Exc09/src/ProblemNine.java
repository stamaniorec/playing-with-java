import java.util.Scanner;

public class ProblemNine {

	public static void main(String[] args) {
		
		// reverse a number
		// average of a series
		// linear equation solver
		
		System.out.println("Please enter an option.");
		System.out.println("1. Reverse a given number");
		System.out.println("2. Calculate average of a series");
		System.out.println("3. Linear equation solver");
		
		Scanner input = new Scanner(System.in);
		int userChoice = input.nextInt();
		
		switch(userChoice) {
		case 1:
			int number = input.nextInt();
			if(number >= 0) {
				System.out.println("Reverse is: " + reverseNumber(number));
			} else { 
				System.out.println("Your number must be positive.");
			}
			break;
		case 2:
			int[] series = { 1, 2, 3, 4, 5 };
			System.out.println("Average of this series is: " + averageOfSeries(series));
			break;
		case 3:
			double a = input.nextDouble();
			double b = input.nextDouble();
			if(a == 0) {
				System.out.println("a can not be zero.");
				break;
			}
			System.out.println("x = " + linearEquationSolver(a, b));
			break;
		}
		
		input.close();
		
	}
	
	public static int reverseNumber(int num) {
		int result = 0;
		while(num != 0) {
			result = result * 10 + num % 10;
			num /= 10;
		}
		return result;
	}
	
	public static double averageOfSeries(int[] arr) {
		double result = 0;
		for(int i = 0; i < arr.length; i++) {
			result += arr[i];
		}
		return result / arr.length;
	}
	
	public static double linearEquationSolver(double a, double b) {
		// ax + b = 0;
		return - b / a;
	}

}
