import java.util.Scanner;

public class ProblemNine {

	// subarray with given sum
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter sum you wanna look for: ");
		int sum = input.nextInt();
		
		int[] array = { 4, 3, 1, 4, 2, 5, 8 };
		boolean found = false;
		int[] subarray = {0};
		
		// I don't even wanna think about the time complexity 
		// of this algorithm :D 
		for (int i = 0; i < array.length; i++) {
			int cur_sum = array[i];
			
			for (int j = i+1; j < array.length; j++) {
				cur_sum += array[j];
				
				if (cur_sum == sum) {
					found = true;
					
					subarray = new int[j-i+1];
					for(int k = 0; k < j - i + 1; k++) {
						subarray[k] = array[i+k];
					}
					
					break;
				} else if (cur_sum > sum) {
					break;
				}
			}
		}
		
		if (!found) {
			System.out.println("No such subarray exists.");
		} else { 
			for (int z = 0; z < subarray.length; z++) {
				System.out.print(subarray[z] + " ");
			}
		}
		
		input.close();
		
	}
	
}
