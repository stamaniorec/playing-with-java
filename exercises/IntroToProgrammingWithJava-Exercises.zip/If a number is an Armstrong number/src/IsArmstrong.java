class IsArmstrong {
	
	boolean isArmstrong(int number) {
	
		int holder = number;
		NumberOfDigits digitsObject = new NumberOfDigits(number);
		int numDigits = digitsObject.numDigits();
		Power p = new Power();
		int power;
		int result = 0;
		while (number != 0) {
			power = p.power(number % 10, numDigits);
			result += power;
			number /= 10;
		}
		return (result == holder);
		
	}
	
}
