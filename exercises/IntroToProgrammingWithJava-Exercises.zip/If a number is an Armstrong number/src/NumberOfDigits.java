
public class NumberOfDigits {
	
	private int number;
	
	public NumberOfDigits(int val) {
		number = val;
	}
	
	public int numDigits() {
		int counter = 0;
		
		int temp = number;
		
		while (temp != 0) {
			counter++;
			temp /= 10;
		}
		
		return counter;
	}
	
	
}
