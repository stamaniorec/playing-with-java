
public class Power {
	
	public int power(int base, int exponent) {
		if (exponent == 0) {
			return 0;
		}
		int result = 1;
		while (exponent > 0) {
			result *= base;
			exponent--;
		}
		return result;
	}
}
