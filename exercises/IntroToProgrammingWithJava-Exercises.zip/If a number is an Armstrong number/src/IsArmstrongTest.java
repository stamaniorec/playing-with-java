public class IsArmstrongTest {
	public static void main(String[] args) {
		// I have yet to learn how to read input from the user... 
		IsArmstrong a = new IsArmstrong();
		System.out.println("Is the given number an Armstrong number?");
		System.out.println(a.isArmstrong(153));
	}
}
