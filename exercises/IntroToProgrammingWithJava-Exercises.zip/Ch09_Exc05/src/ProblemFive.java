
public class ProblemFive {

	// 1 2 3 (2) -> false
	// 1 3 2 (3) -> true
	// 1 2 3 (1) -> false 
	// 1 2 3 (3) -> false
	public static void main(String[] args) {
		
		int[] array = { 1, 3, 2 };
		
		System.out.println(isGreaterThanNeighbors(array, 3));
		
	}
	
	public static boolean isGreaterThanNeighbors(int[] arr, int index) {
		System.out.println((index-1) + " " + (index+1));
		if(index-1 < 0 || index+1 >= arr.length) {
			return false;
		}
		if(arr[index] > arr[index-1] && arr[index] > arr[index+1]) {
			return true;
		} else { 
			return false;
		}
	}
	
}
