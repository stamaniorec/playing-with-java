import java.util.Scanner;


public class PerimeterAndAreaOfCircle {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter radius: ");
		double r = input.nextDouble();
		
		System.out.println("Perimeter: " + (2 * Math.PI * r));
		System.out.println("Area: " + (r*r * Math.PI));
		
		input.close(); // Um that Java book said not to do that
						// but Eclipse doesn't seem to agree with that
		
	}
	
}
